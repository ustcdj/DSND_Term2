from setuptools import setup

setup(name='udacity_dsnd_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['udacity_dsnd_distributions'],
      author = 'DJ Dong',
      author_email = 'ustcdj@hotmail.com',
      zip_safe=False)
